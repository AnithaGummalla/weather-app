import { Box } from "@mui/material";

const floatingElementsData = [
  { top: "10%", left: "15%", size: 50, color: "rgba(38, 98, 172, 0.3)" },
  { top: "30%", left: "3%", size: 70, color: "rgba(255,255,255,0.2)" },
  // { top: "50%", left: "60%", size: 80, color: "rgba(255,255,255,0.25)" },
  { top: "60%", left: "90%", size: 35, color: "rgba(255,255,255,0.3)" },
  { top: "40%", left: "45%", size: 35, color: "rgba(255,255,255,0.3)" },
  // { top: "80%", left: "28%", size: 35, color: "rgba(255,255,255,0.3)" },
  { top: "90%", left: "56%", size: 35, color: "rgba(38, 98, 172, 0.3)" },
];

const FloatingElements = () => (
  <>
    {floatingElementsData.map((elem, idx) => (
      <Box
        key={idx}
        sx={{
          position: "absolute",
          top: elem.top,
          left: elem.left,
          width: elem.size,
          height: elem.size,
          borderRadius: "50%",
          backgroundColor: elem.color,
          animation: `float ${6 + idx * 2}s ease-in-out infinite`,
          "@keyframes float": {
            "0%, 100%": { transform: "translateY(0) rotate(0deg) scale(1)" },
            "25%": { transform: "translateY(-10px) rotate(-1deg) scale(1.05)" },
            "50%": { transform: "translateY(-20px) rotate(1deg) scale(1.1)" },
            "75%": { transform: "translateY(-10px) rotate(-1deg) scale(1.05)" },
          },
        }}
      />
    ))}
  </>
);
export default FloatingElements;
